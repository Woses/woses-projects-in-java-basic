
public class Programm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Mein zweites Java-Programm.");
	}

}
