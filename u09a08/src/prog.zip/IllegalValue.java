
public class IllegalValue extends RuntimeException{
	IllegalValue() {
        super("Werte au�erhalb der Spezifikation!");
    }
}
