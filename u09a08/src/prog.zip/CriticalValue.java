
public class CriticalValue extends Exception {
	CriticalValue() {
        super("Erlaubter Wert im kritischen Bereich!");
    }
}
