import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;


public class LaborStand {

	public static void main(String[] args) {
		
		int maxAnzahlDatensaetze = Integer.parseInt(args[0]);
		MessReihe messReihe = new MessReihe(maxAnzahlDatensaetze);
		Scanner sc = null;
		
		
		try {
			sc = new Scanner(new File(args[1]));
			while(sc.hasNext()){
			   	try{
			  		messReihe.neueMessung(sc.nextInt(),sc.nextDouble(),sc.nextDouble());
			   	}catch (TooMuchData e) {
			   		System.out.println("Fehler: When Shit hits the Fan!");
			   	}catch (IllegalValue e) {
			   		System.out.println("Fehler: Eyyyyy jo dont shit here!");
			   	}catch (CriticalValue e) {
			   		System.out.println("Fehler: Eyyyyy jo dont do shit!");
			   		System.exit(1);
			   	}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Fehler: Eyyyyy jo do search shit!");
			System.exit(1);
		} catch (NumberFormatException e) {
			System.out.println("Fehler: Numberphile Shitride!");
		} catch (Exception e) {
			System.out.println("Fehler: What even have you done?");
		}
		
		sc.close();
		
		double [] mittelwerte = messReihe.ermittleMittelwerte();
		System.out.println("Durchschnitt von Umdrehungszahl: "+ mittelwerte[0]);
		System.out.println("Durchschnitt von Temperatur: "+ mittelwerte[1]);
		System.out.println("Durchschnitt von Ladedruck: "+ mittelwerte[2]);

	}

}
