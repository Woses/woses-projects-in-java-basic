
public class TooMuchData extends RuntimeException{
	TooMuchData() {
        super("Mehr Daten als in einer Me�reihe erlaubt sind angefallen!");
    }
}
